<?php
/**
 * The template for displaying the footer in PWA.
 *
 * @package Nueve4
 * @since   2.4.3
 */

?>

<?php wp_footer(); ?>

</body>

</html>
