### How to help translating Nueve4 ?

You can help getting Nueve4 translated by using the [WordPress.org](https://translate.wordpress.org/projects/wp-themes/nueve4/) translation page.

### How to generate the translation file? 

You can run the following commands to build the translation file: 
* `yarn install --frozen-lockfile`
* `yarn run build:makepot`
