<?php
/**
 * Comprehensive Customizer System
 * Full-featured customizer with all modern controls
 *
 * @package Nueve4\Customizer
 */

namespace Nueve4\Customizer;

class Comprehensive_Customizer {
	
	public function init() {
		add_action( 'customize_register', [ $this, 'register_customizer' ], 10 );
		add_action( 'wp_head', [ $this, 'output_css' ] );
		add_action( 'customize_preview_init', [ $this, 'preview_scripts' ] );
	}
	
	public function register_customizer( $wp_customize ) {
		$this->add_global_colors_panel( $wp_customize );
		$this->add_typography_panel( $wp_customize );
		$this->add_layout_panel( $wp_customize );
		$this->add_header_panel( $wp_customize );
		$this->add_footer_panel( $wp_customize );
		$this->add_blog_panel( $wp_customize );
		$this->add_woocommerce_panel( $wp_customize );
		$this->add_performance_panel( $wp_customize );
	}
	
	/**
	 * Global Colors Panel
	 */
	private function add_global_colors_panel( $wp_customize ) {
		$wp_customize->add_panel( 'nueve4_colors_panel', [
			'title' => 'Colors & Styling',
			'priority' => 30,
		]);
		
		// Primary Colors Section
		$wp_customize->add_section( 'nueve4_primary_colors', [
			'title' => 'Primary Colors',
			'panel' => 'nueve4_colors_panel',
			'priority' => 10,
		]);
		
		$colors = [
			'primary' => [ 'Primary Color', '#0073aa' ],
			'secondary' => [ 'Secondary Color', '#005177' ],
			'accent' => [ 'Accent Color', '#ff6b35' ],
			'text' => [ 'Text Color', '#333333' ],
			'text_light' => [ 'Light Text Color', '#666666' ],
			'link' => [ 'Link Color', '#0073aa' ],
			'link_hover' => [ 'Link Hover Color', '#005177' ],
		];
		
		foreach ( $colors as $key => $data ) {
			$wp_customize->add_setting( "nueve4_{$key}_color", [
				'default' => $data[1],
				'sanitize_callback' => 'sanitize_hex_color',
				'transport' => 'postMessage',
			]);
			$wp_customize->add_control( new \WP_Customize_Color_Control( $wp_customize, "nueve4_{$key}_color", [
				'label' => $data[0],
				'section' => 'nueve4_primary_colors',
			]));
		}
		
		// Background Colors Section
		$wp_customize->add_section( 'nueve4_background_colors', [
			'title' => 'Background Colors',
			'panel' => 'nueve4_colors_panel',
			'priority' => 20,
		]);
		
		$bg_colors = [
			'body_bg' => [ 'Body Background', '#ffffff' ],
			'content_bg' => [ 'Content Background', '#ffffff' ],
			'sidebar_bg' => [ 'Sidebar Background', '#f8f9fa' ],
			'footer_bg' => [ 'Footer Background', '#2c3e50' ],
		];
		
		foreach ( $bg_colors as $key => $data ) {
			$wp_customize->add_setting( "nueve4_{$key}", [
				'default' => $data[1],
				'sanitize_callback' => 'sanitize_hex_color',
				'transport' => 'postMessage',
			]);
			$wp_customize->add_control( new \WP_Customize_Color_Control( $wp_customize, "nueve4_{$key}", [
				'label' => $data[0],
				'section' => 'nueve4_background_colors',
			]));
		}
	}
	
	/**
	 * Typography Panel
	 */
	private function add_typography_panel( $wp_customize ) {
		$wp_customize->add_panel( 'nueve4_typography_panel', [
			'title' => 'Typography',
			'priority' => 40,
		]);
		
		// Body Typography
		$wp_customize->add_section( 'nueve4_body_typography', [
			'title' => 'Body Typography',
			'panel' => 'nueve4_typography_panel',
			'priority' => 10,
		]);
		
		$fonts = [
			'system-ui, -apple-system, sans-serif' => 'System Font',
			'Arial, sans-serif' => 'Arial',
			'Helvetica, sans-serif' => 'Helvetica',
			'Georgia, serif' => 'Georgia',
			'Times, serif' => 'Times New Roman',
			'"Courier New", monospace' => 'Courier New',
			'Verdana, sans-serif' => 'Verdana',
			'Tahoma, sans-serif' => 'Tahoma',
			'"Trebuchet MS", sans-serif' => 'Trebuchet MS',
			'"Palatino Linotype", serif' => 'Palatino',
		];
		
		$wp_customize->add_setting( 'nueve4_body_font_family', [
			'default' => 'system-ui, -apple-system, sans-serif',
			'sanitize_callback' => 'sanitize_text_field',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_body_font_family', [
			'label' => 'Body Font Family',
			'section' => 'nueve4_body_typography',
			'type' => 'select',
			'choices' => $fonts,
		]);
		
		$wp_customize->add_setting( 'nueve4_body_font_size', [
			'default' => 16,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_body_font_size', [
			'label' => 'Body Font Size (px)',
			'section' => 'nueve4_body_typography',
			'type' => 'range',
			'input_attrs' => [ 'min' => 12, 'max' => 24, 'step' => 1 ],
		]);
		
		$wp_customize->add_setting( 'nueve4_body_line_height', [
			'default' => 1.6,
			'sanitize_callback' => [ $this, 'sanitize_float' ],
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_body_line_height', [
			'label' => 'Body Line Height',
			'section' => 'nueve4_body_typography',
			'type' => 'range',
			'input_attrs' => [ 'min' => 1, 'max' => 3, 'step' => 0.1 ],
		]);
		
		// Headings Typography
		$wp_customize->add_section( 'nueve4_headings_typography', [
			'title' => 'Headings Typography',
			'panel' => 'nueve4_typography_panel',
			'priority' => 20,
		]);
		
		$wp_customize->add_setting( 'nueve4_headings_font_family', [
			'default' => 'inherit',
			'sanitize_callback' => 'sanitize_text_field',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_headings_font_family', [
			'label' => 'Headings Font Family',
			'section' => 'nueve4_headings_typography',
			'type' => 'select',
			'choices' => array_merge( [ 'inherit' => 'Inherit from Body' ], $fonts ),
		]);
		
		foreach ( [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ] as $heading ) {
			$default_sizes = [ 'h1' => 32, 'h2' => 28, 'h3' => 24, 'h4' => 20, 'h5' => 18, 'h6' => 16 ];
			
			$wp_customize->add_setting( "nueve4_{$heading}_font_size", [
				'default' => $default_sizes[$heading],
				'sanitize_callback' => 'absint',
				'transport' => 'postMessage',
			]);
			$wp_customize->add_control( "nueve4_{$heading}_font_size", [
				'label' => strtoupper($heading) . ' Font Size (px)',
				'section' => 'nueve4_headings_typography',
				'type' => 'range',
				'input_attrs' => [ 'min' => 12, 'max' => 48, 'step' => 1 ],
			]);
		}
	}
	
	/**
	 * Layout Panel
	 */
	private function add_layout_panel( $wp_customize ) {
		$wp_customize->add_panel( 'nueve4_layout_panel', [
			'title' => 'Layout & Structure',
			'priority' => 50,
		]);
		
		// Container Settings
		$wp_customize->add_section( 'nueve4_container_settings', [
			'title' => 'Container Settings',
			'panel' => 'nueve4_layout_panel',
			'priority' => 10,
		]);
		
		$wp_customize->add_setting( 'nueve4_container_width', [
			'default' => 1200,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_container_width', [
			'label' => 'Container Max Width (px)',
			'section' => 'nueve4_container_settings',
			'type' => 'range',
			'input_attrs' => [ 'min' => 800, 'max' => 1600, 'step' => 10 ],
		]);
		
		$wp_customize->add_setting( 'nueve4_container_padding', [
			'default' => 20,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_container_padding', [
			'label' => 'Container Padding (px)',
			'section' => 'nueve4_container_settings',
			'type' => 'range',
			'input_attrs' => [ 'min' => 0, 'max' => 50, 'step' => 5 ],
		]);
		
		// Sidebar Settings
		$wp_customize->add_section( 'nueve4_sidebar_settings', [
			'title' => 'Sidebar Settings',
			'panel' => 'nueve4_layout_panel',
			'priority' => 20,
		]);
		
		$wp_customize->add_setting( 'nueve4_sidebar_position', [
			'default' => 'right',
			'sanitize_callback' => 'sanitize_text_field',
		]);
		$wp_customize->add_control( 'nueve4_sidebar_position', [
			'label' => 'Sidebar Position',
			'section' => 'nueve4_sidebar_settings',
			'type' => 'radio',
			'choices' => [
				'none' => 'No Sidebar',
				'left' => 'Left Sidebar',
				'right' => 'Right Sidebar',
			],
		]);
		
		$wp_customize->add_setting( 'nueve4_sidebar_width', [
			'default' => 30,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_sidebar_width', [
			'label' => 'Sidebar Width (%)',
			'section' => 'nueve4_sidebar_settings',
			'type' => 'range',
			'input_attrs' => [ 'min' => 20, 'max' => 40, 'step' => 1 ],
		]);
	}
	
	/**
	 * Header Panel
	 */
	private function add_header_panel( $wp_customize ) {
		$wp_customize->add_panel( 'nueve4_header_panel', [
			'title' => 'Header Settings',
			'priority' => 60,
		]);
		
		// Header Layout
		$wp_customize->add_section( 'nueve4_header_layout', [
			'title' => 'Header Layout',
			'panel' => 'nueve4_header_panel',
			'priority' => 10,
		]);
		
		$wp_customize->add_setting( 'nueve4_header_height', [
			'default' => 80,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_header_height', [
			'label' => 'Header Height (px)',
			'section' => 'nueve4_header_layout',
			'type' => 'range',
			'input_attrs' => [ 'min' => 60, 'max' => 150, 'step' => 5 ],
		]);
		
		$wp_customize->add_setting( 'nueve4_header_sticky', [
			'default' => false,
			'sanitize_callback' => 'wp_validate_boolean',
		]);
		$wp_customize->add_control( 'nueve4_header_sticky', [
			'label' => 'Sticky Header',
			'section' => 'nueve4_header_layout',
			'type' => 'checkbox',
		]);
		
		$wp_customize->add_setting( 'nueve4_header_transparent', [
			'default' => false,
			'sanitize_callback' => 'wp_validate_boolean',
		]);
		$wp_customize->add_control( 'nueve4_header_transparent', [
			'label' => 'Transparent Header',
			'section' => 'nueve4_header_layout',
			'type' => 'checkbox',
		]);
		
		// Header Colors
		$wp_customize->add_section( 'nueve4_header_colors', [
			'title' => 'Header Colors',
			'panel' => 'nueve4_header_panel',
			'priority' => 20,
		]);
		
		$header_colors = [
			'header_bg' => [ 'Header Background', '#ffffff' ],
			'header_text' => [ 'Header Text Color', '#333333' ],
			'menu_link' => [ 'Menu Link Color', '#333333' ],
			'menu_link_hover' => [ 'Menu Link Hover', '#0073aa' ],
		];
		
		foreach ( $header_colors as $key => $data ) {
			$wp_customize->add_setting( "nueve4_{$key}", [
				'default' => $data[1],
				'sanitize_callback' => 'sanitize_hex_color',
				'transport' => 'postMessage',
			]);
			$wp_customize->add_control( new \WP_Customize_Color_Control( $wp_customize, "nueve4_{$key}", [
				'label' => $data[0],
				'section' => 'nueve4_header_colors',
			]));
		}
	}
	
	/**
	 * Footer Panel
	 */
	private function add_footer_panel( $wp_customize ) {
		$wp_customize->add_section( 'nueve4_footer_settings', [
			'title' => 'Footer Settings',
			'priority' => 70,
		]);
		
		$wp_customize->add_setting( 'nueve4_footer_widgets', [
			'default' => 3,
			'sanitize_callback' => 'absint',
		]);
		$wp_customize->add_control( 'nueve4_footer_widgets', [
			'label' => 'Footer Widget Columns',
			'section' => 'nueve4_footer_settings',
			'type' => 'range',
			'input_attrs' => [ 'min' => 1, 'max' => 4, 'step' => 1 ],
		]);
		
		$wp_customize->add_setting( 'nueve4_footer_copyright', [
			'default' => 'Copyright © 2024 Your Site Name. All rights reserved.',
			'sanitize_callback' => 'sanitize_text_field',
		]);
		$wp_customize->add_control( 'nueve4_footer_copyright', [
			'label' => 'Footer Copyright Text',
			'section' => 'nueve4_footer_settings',
			'type' => 'textarea',
		]);
	}
	
	/**
	 * Blog Panel
	 */
	private function add_blog_panel( $wp_customize ) {
		$wp_customize->add_section( 'nueve4_blog_settings', [
			'title' => 'Blog Settings',
			'priority' => 80,
		]);
		
		$wp_customize->add_setting( 'nueve4_blog_layout', [
			'default' => 'grid',
			'sanitize_callback' => 'sanitize_text_field',
		]);
		$wp_customize->add_control( 'nueve4_blog_layout', [
			'label' => 'Blog Layout',
			'section' => 'nueve4_blog_settings',
			'type' => 'radio',
			'choices' => [
				'list' => 'List Layout',
				'grid' => 'Grid Layout',
				'masonry' => 'Masonry Layout',
			],
		]);
		
		$wp_customize->add_setting( 'nueve4_excerpt_length', [
			'default' => 150,
			'sanitize_callback' => 'absint',
		]);
		$wp_customize->add_control( 'nueve4_excerpt_length', [
			'label' => 'Excerpt Length (words)',
			'section' => 'nueve4_blog_settings',
			'type' => 'range',
			'input_attrs' => [ 'min' => 50, 'max' => 300, 'step' => 10 ],
		]);
		
		$wp_customize->add_setting( 'nueve4_show_featured_image', [
			'default' => true,
			'sanitize_callback' => 'wp_validate_boolean',
		]);
		$wp_customize->add_control( 'nueve4_show_featured_image', [
			'label' => 'Show Featured Images',
			'section' => 'nueve4_blog_settings',
			'type' => 'checkbox',
		]);
	}
	
	/**
	 * WooCommerce Panel
	 */
	private function add_woocommerce_panel( $wp_customize ) {
		if ( ! class_exists( 'WooCommerce' ) ) return;
		
		$wp_customize->add_section( 'nueve4_woocommerce_settings', [
			'title' => 'WooCommerce Settings',
			'priority' => 90,
		]);
		
		$wp_customize->add_setting( 'nueve4_shop_columns', [
			'default' => 3,
			'sanitize_callback' => 'absint',
		]);
		$wp_customize->add_control( 'nueve4_shop_columns', [
			'label' => 'Shop Columns',
			'section' => 'nueve4_woocommerce_settings',
			'type' => 'range',
			'input_attrs' => [ 'min' => 2, 'max' => 5, 'step' => 1 ],
		]);
		
		$wp_customize->add_setting( 'nueve4_products_per_page', [
			'default' => 12,
			'sanitize_callback' => 'absint',
		]);
		$wp_customize->add_control( 'nueve4_products_per_page', [
			'label' => 'Products Per Page',
			'section' => 'nueve4_woocommerce_settings',
			'type' => 'range',
			'input_attrs' => [ 'min' => 6, 'max' => 24, 'step' => 3 ],
		]);
	}
	
	/**
	 * Performance Panel
	 */
	private function add_performance_panel( $wp_customize ) {
		$wp_customize->add_section( 'nueve4_performance_settings', [
			'title' => 'Performance Settings',
			'priority' => 100,
		]);
		
		$wp_customize->add_setting( 'nueve4_minify_css', [
			'default' => true,
			'sanitize_callback' => 'wp_validate_boolean',
		]);
		$wp_customize->add_control( 'nueve4_minify_css', [
			'label' => 'Minify CSS Output',
			'section' => 'nueve4_performance_settings',
			'type' => 'checkbox',
		]);
		
		$wp_customize->add_setting( 'nueve4_lazy_load', [
			'default' => true,
			'sanitize_callback' => 'wp_validate_boolean',
		]);
		$wp_customize->add_control( 'nueve4_lazy_load', [
			'label' => 'Enable Lazy Loading',
			'section' => 'nueve4_performance_settings',
			'type' => 'checkbox',
		]);
	}
	
	public function sanitize_float( $value ) {
		return floatval( $value );
	}
	
	/**
	 * Output comprehensive CSS
	 */
	public function output_css() {
		$css = $this->generate_comprehensive_css();
		if ( get_theme_mod( 'nueve4_minify_css', true ) ) {
			$css = $this->minify_css( $css );
		}
		echo '<style id="nueve4-comprehensive-css">' . $css . '</style>';
	}
	
	private function generate_comprehensive_css() {
		$css = ':root {';
		$css .= '--primary-color: ' . get_theme_mod( 'nueve4_primary_color', '#0073aa' ) . ';';
		$css .= '--secondary-color: ' . get_theme_mod( 'nueve4_secondary_color', '#005177' ) . ';';
		$css .= '--accent-color: ' . get_theme_mod( 'nueve4_accent_color', '#ff6b35' ) . ';';
		$css .= '--text-color: ' . get_theme_mod( 'nueve4_text_color', '#333333' ) . ';';
		$css .= '--link-color: ' . get_theme_mod( 'nueve4_link_color', '#0073aa' ) . ';';
		$css .= '--container-width: ' . get_theme_mod( 'nueve4_container_width', 1200 ) . 'px;';
		$css .= '--header-height: ' . get_theme_mod( 'nueve4_header_height', 80 ) . 'px;';
		$css .= '}';
		
		$css .= 'body { 
			color: var(--text-color); 
			font-family: ' . get_theme_mod( 'nueve4_body_font_family', 'system-ui, -apple-system, sans-serif' ) . '; 
			font-size: ' . get_theme_mod( 'nueve4_body_font_size', 16 ) . 'px; 
			line-height: ' . get_theme_mod( 'nueve4_body_line_height', 1.6 ) . '; 
			background-color: ' . get_theme_mod( 'nueve4_body_bg', '#ffffff' ) . ';
		}';
		
		$css .= 'a { color: var(--link-color); }';
		$css .= 'a:hover { color: ' . get_theme_mod( 'nueve4_link_hover_color', '#005177' ) . '; }';
		
		$headings_font = get_theme_mod( 'nueve4_headings_font_family', 'inherit' );
		if ( $headings_font !== 'inherit' ) {
			$css .= 'h1, h2, h3, h4, h5, h6 { font-family: ' . $headings_font . '; }';
		}
		
		foreach ( [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ] as $heading ) {
			$default_sizes = [ 'h1' => 32, 'h2' => 28, 'h3' => 24, 'h4' => 20, 'h5' => 18, 'h6' => 16 ];
			$size = get_theme_mod( "nueve4_{$heading}_font_size", $default_sizes[$heading] );
			$css .= "{$heading} { font-size: {$size}px; }";
		}
		
		$css .= '.container, .nv-container { max-width: var(--container-width); margin: 0 auto; padding: 0 ' . get_theme_mod( 'nueve4_container_padding', 20 ) . 'px; }';
		
		$css .= '.site-header { 
			min-height: var(--header-height); 
			background-color: ' . get_theme_mod( 'nueve4_header_bg', '#ffffff' ) . '; 
			color: ' . get_theme_mod( 'nueve4_header_text', '#333333' ) . ';
		}';
		
		if ( get_theme_mod( 'nueve4_header_sticky', false ) ) {
			$css .= '.site-header { position: sticky; top: 0; z-index: 999; }';
		}
		
		if ( get_theme_mod( 'nueve4_header_transparent', false ) ) {
			$css .= '.site-header { background-color: transparent; }';
		}
		
		$css .= '.site-footer { background-color: ' . get_theme_mod( 'nueve4_footer_bg', '#2c3e50' ) . '; }';
		
		$css .= '.btn-primary, input[type="submit"], .button { 
			background-color: var(--primary-color); 
			border-color: var(--primary-color); 
			color: #ffffff;
		}';
		
		$css .= '.btn-primary:hover, input[type="submit"]:hover, .button:hover { 
			background-color: var(--secondary-color); 
			border-color: var(--secondary-color); 
		}';
		
		$sidebar_width = get_theme_mod( 'nueve4_sidebar_width', 30 );
		$content_width = 100 - $sidebar_width;
		$css .= ".has-sidebar .content-area { width: {$content_width}%; }";
		$css .= ".has-sidebar .sidebar { width: {$sidebar_width}%; }";
		
		return $css;
	}
	
	private function minify_css( $css ) {
		$css = preg_replace( '/\s+/', ' ', $css );
		$css = preg_replace( '/;\s*}/', '}', $css );
		$css = str_replace( array( '; ', ' {', '{ ', ' }', '} ' ), array( ';', '{', '{', '}', '}' ), $css );
		return trim( $css );
	}
	
	public function preview_scripts() {
		wp_enqueue_script( 'nueve4-customizer-preview', get_template_directory_uri() . '/assets/js/customizer-preview.js', [ 'customize-preview' ], NUEVE4_VERSION, true );
	}
}