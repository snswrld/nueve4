<?php
/**
 * Clean Functional Customizer
 * Replaces the broken existing customizer with working controls
 *
 * @package Nueve4\Customizer
 */

namespace Nueve4\Customizer;

/**
 * Clean customizer that actually works
 */
class Clean_Customizer {
	
	public function init() {
		add_action( 'customize_register', [ $this, 'remove_broken_customizer' ], 1 );
		add_action( 'customize_register', [ $this, 'add_working_customizer' ], 999 );
		add_action( 'wp_head', [ $this, 'output_css' ] );
	}
	
	/**
	 * Remove all broken customizer sections
	 */
	public function remove_broken_customizer( $wp_customize ) {
		// Remove ALL existing panels and sections
		$all_panels = $wp_customize->panels();
		foreach ( $all_panels as $panel_id => $panel ) {
			if ( strpos( $panel_id, 'nav_menus' ) === false && strpos( $panel_id, 'widgets' ) === false ) {
				$wp_customize->remove_panel( $panel_id );
			}
		}
		
		$all_sections = $wp_customize->sections();
		foreach ( $all_sections as $section_id => $section ) {
			if ( strpos( $section_id, 'nav' ) === false && strpos( $section_id, 'widget' ) === false && 
				 strpos( $section_id, 'static_front_page' ) === false && strpos( $section_id, 'title_tagline' ) === false ) {
				$wp_customize->remove_section( $section_id );
			}
		}
	}
	
	/**
	 * Add working customizer
	 */
	public function add_working_customizer( $wp_customize ) {
		$this->add_colors_section( $wp_customize );
		$this->add_typography_section( $wp_customize );
		$this->add_layout_section( $wp_customize );
		$this->add_header_section( $wp_customize );
	}
	
	/**
	 * Colors section with actual color pickers
	 */
	private function add_colors_section( $wp_customize ) {
		$wp_customize->add_section( 'nueve4_colors', [
			'title' => 'Colors',
			'priority' => 40,
		]);
		
		// Primary color
		$wp_customize->add_setting( 'nueve4_primary_color', [
			'default' => '#0073aa',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( new \WP_Customize_Color_Control( $wp_customize, 'nueve4_primary_color', [
			'label' => 'Primary Color',
			'section' => 'nueve4_colors',
		]));
		
		// Text color
		$wp_customize->add_setting( 'nueve4_text_color', [
			'default' => '#333333',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( new \WP_Customize_Color_Control( $wp_customize, 'nueve4_text_color', [
			'label' => 'Text Color',
			'section' => 'nueve4_colors',
		]));
		
		// Link color
		$wp_customize->add_setting( 'nueve4_link_color', [
			'default' => '#0073aa',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( new \WP_Customize_Color_Control( $wp_customize, 'nueve4_link_color', [
			'label' => 'Link Color',
			'section' => 'nueve4_colors',
		]));
	}
	
	/**
	 * Typography section with working font controls
	 */
	private function add_typography_section( $wp_customize ) {
		$wp_customize->add_section( 'nueve4_typography', [
			'title' => 'Typography',
			'priority' => 50,
		]);
		
		// Body font
		$wp_customize->add_setting( 'nueve4_body_font', [
			'default' => 'system-ui, sans-serif',
			'sanitize_callback' => 'sanitize_text_field',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_body_font', [
			'label' => 'Body Font',
			'section' => 'nueve4_typography',
			'type' => 'select',
			'choices' => [
				'system-ui, sans-serif' => 'System Font',
				'Arial, sans-serif' => 'Arial',
				'Georgia, serif' => 'Georgia',
				'Times, serif' => 'Times',
				'Helvetica, sans-serif' => 'Helvetica',
			],
		]);
		
		// Font size
		$wp_customize->add_setting( 'nueve4_font_size', [
			'default' => 16,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_font_size', [
			'label' => 'Font Size (px)',
			'section' => 'nueve4_typography',
			'type' => 'range',
			'input_attrs' => [ 'min' => 12, 'max' => 24, 'step' => 1 ],
		]);
		
		// Heading font
		$wp_customize->add_setting( 'nueve4_heading_font', [
			'default' => 'inherit',
			'sanitize_callback' => 'sanitize_text_field',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_heading_font', [
			'label' => 'Heading Font',
			'section' => 'nueve4_typography',
			'type' => 'select',
			'choices' => [
				'inherit' => 'Same as Body',
				'Arial, sans-serif' => 'Arial',
				'Georgia, serif' => 'Georgia',
				'Times, serif' => 'Times',
				'Helvetica, sans-serif' => 'Helvetica',
			],
		]);
	}
	
	/**
	 * Layout section with working controls
	 */
	private function add_layout_section( $wp_customize ) {
		$wp_customize->add_section( 'nueve4_layout', [
			'title' => 'Layout',
			'priority' => 60,
		]);
		
		// Container width
		$wp_customize->add_setting( 'nueve4_container_width', [
			'default' => 1200,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_container_width', [
			'label' => 'Container Width (px)',
			'section' => 'nueve4_layout',
			'type' => 'range',
			'input_attrs' => [ 'min' => 800, 'max' => 1600, 'step' => 10 ],
		]);
		
		// Sidebar position
		$wp_customize->add_setting( 'nueve4_sidebar_position', [
			'default' => 'right',
			'sanitize_callback' => 'sanitize_text_field',
		]);
		$wp_customize->add_control( 'nueve4_sidebar_position', [
			'label' => 'Sidebar Position',
			'section' => 'nueve4_layout',
			'type' => 'radio',
			'choices' => [
				'none' => 'No Sidebar',
				'left' => 'Left Sidebar',
				'right' => 'Right Sidebar',
			],
		]);
	}
	
	/**
	 * Header section with working controls
	 */
	private function add_header_section( $wp_customize ) {
		$wp_customize->add_section( 'nueve4_header', [
			'title' => 'Header',
			'priority' => 70,
		]);
		
		// Header height
		$wp_customize->add_setting( 'nueve4_header_height', [
			'default' => 80,
			'sanitize_callback' => 'absint',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( 'nueve4_header_height', [
			'label' => 'Header Height (px)',
			'section' => 'nueve4_header',
			'type' => 'range',
			'input_attrs' => [ 'min' => 60, 'max' => 120, 'step' => 5 ],
		]);
		
		// Sticky header
		$wp_customize->add_setting( 'nueve4_sticky_header', [
			'default' => false,
			'sanitize_callback' => 'wp_validate_boolean',
		]);
		$wp_customize->add_control( 'nueve4_sticky_header', [
			'label' => 'Sticky Header',
			'section' => 'nueve4_header',
			'type' => 'checkbox',
		]);
		
		// Header background
		$wp_customize->add_setting( 'nueve4_header_bg', [
			'default' => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport' => 'postMessage',
		]);
		$wp_customize->add_control( new \WP_Customize_Color_Control( $wp_customize, 'nueve4_header_bg', [
			'label' => 'Header Background',
			'section' => 'nueve4_header',
		]));
	}
	
	/**
	 * Output working CSS
	 */
	public function output_css() {
		$primary_color = get_theme_mod( 'nueve4_primary_color', '#0073aa' );
		$text_color = get_theme_mod( 'nueve4_text_color', '#333333' );
		$link_color = get_theme_mod( 'nueve4_link_color', '#0073aa' );
		$body_font = get_theme_mod( 'nueve4_body_font', 'system-ui, sans-serif' );
		$font_size = get_theme_mod( 'nueve4_font_size', 16 );
		$heading_font = get_theme_mod( 'nueve4_heading_font', 'inherit' );
		$container_width = get_theme_mod( 'nueve4_container_width', 1200 );
		$header_height = get_theme_mod( 'nueve4_header_height', 80 );
		$sticky_header = get_theme_mod( 'nueve4_sticky_header', false );
		$header_bg = get_theme_mod( 'nueve4_header_bg', '#ffffff' );
		
		echo '<style id="nueve4-customizer-css">';
		echo 'body { color: ' . $text_color . '; font-family: ' . $body_font . '; font-size: ' . $font_size . 'px; }';
		echo 'a { color: ' . $link_color . '; }';
		if ( $heading_font !== 'inherit' ) {
			echo 'h1, h2, h3, h4, h5, h6 { font-family: ' . $heading_font . '; }';
		}
		echo '.container, .nv-container { max-width: ' . $container_width . 'px; }';
		echo '.site-header { min-height: ' . $header_height . 'px; background-color: ' . $header_bg . '; }';
		echo '.btn-primary, input[type="submit"] { background-color: ' . $primary_color . '; border-color: ' . $primary_color . '; }';
		if ( $sticky_header ) {
			echo '.site-header { position: sticky; top: 0; z-index: 999; }';
		}
		echo '</style>';
		
		// Add live preview script
		if ( is_customize_preview() ) {
			echo '<script>
			(function($) {
				wp.customize("nueve4_primary_color", function(value) {
					value.bind(function(newval) {
						$(".btn-primary, input[type=submit]").css("background-color", newval);
					});
				});
				wp.customize("nueve4_text_color", function(value) {
					value.bind(function(newval) {
						$("body").css("color", newval);
					});
				});
				wp.customize("nueve4_link_color", function(value) {
					value.bind(function(newval) {
						$("a").css("color", newval);
					});
				});
				wp.customize("nueve4_body_font", function(value) {
					value.bind(function(newval) {
						$("body").css("font-family", newval);
					});
				});
				wp.customize("nueve4_font_size", function(value) {
					value.bind(function(newval) {
						$("body").css("font-size", newval + "px");
					});
				});
				wp.customize("nueve4_container_width", function(value) {
					value.bind(function(newval) {
						$(".container, .nv-container").css("max-width", newval + "px");
					});
				});
				wp.customize("nueve4_header_height", function(value) {
					value.bind(function(newval) {
						$(".site-header").css("min-height", newval + "px");
					});
				});
				wp.customize("nueve4_header_bg", function(value) {
					value.bind(function(newval) {
						$(".site-header").css("background-color", newval);
					});
				});
			})(jQuery);
			</script>';
		}
	}
}