<?php
/**
 * 404 template.
 *
 * @package Nueve4
 */

get_header();
do_action( 'nueve4_do_404' );
get_footer();
